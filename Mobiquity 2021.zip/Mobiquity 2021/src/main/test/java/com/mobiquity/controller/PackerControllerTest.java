package com.mobiquity.controller;


import com.mobiquity.constant.Endpoints;
import com.mobiquity.service.PackerService;
import org.junit.Test;
import org.springframework.boot.test.mock.mockito.MockBean;


import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


public class PackerControllerTest extends AbstractControllerTestBase {

    @MockBean
    private PackerService packerService;

    @Test
    public void whenPacketInputIsCorrect_thenResultIsOk() throws Exception {
       final String result = "4\n-\n2, 7\n6, 9\n";
       final String filePath = "/src/main/resources/testFile.txt";

       doReturn(result).when(packerService).packInput(filePath);

       final String responseJson = getMvc().perform(post(Endpoints.PACK_INPUT).param("filePath", filePath))
               .andExpect(status().isOk())
               .andReturn()
               .getResponse()
               .getContentAsString();

       assertEquals(responseJson, result);
    }

    @Test
    public void whenPackageInputParamIsNotCorrect_theResponseBadRequest() throws Exception {
            final String result = "4\n-\n2, 7\n6, 9\n";
            final String filePath = "/src/main/resources/testFile.txt";

            doReturn(result).when(packerService).packInput(filePath);

            final int responseStatus = getMvc().perform(post(Endpoints.PACK_INPUT))
                    .andExpect(status().isBadRequest())
                    .andReturn()
                    .getResponse()
                    .getStatus();

            assertEquals(400, responseStatus);
    }
}
