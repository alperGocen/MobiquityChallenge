package com.mobiquity.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Endpoints {

    public final String PACK_INPUT = "/api/packageItems";
}
