package com.mobiquity.service;

import com.mobiquity.exception.APIException;
import com.mobiquity.packer.Packer;
import com.mobiquity.service.impl.PackerServiceImpl;
import com.mobiquity.util.Constants;
import com.mobiquity.util.FileUtil;
import com.mobiquity.util.ItemUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

@RunWith(MockitoJUnitRunner.class)
public class PackerServiceTest {

    @InjectMocks
    private PackerServiceImpl packerService;

    @Test
    public void testPackInput() throws APIException {
        final String expectedResult = "4\n-\n2, 7\n6, 9\n";
        final String filePath = "src/main/test/resources/example_input";

        try (MockedStatic<Packer> packer = Mockito.mockStatic(Packer.class)) {
            packer.when(() -> Packer.pack(filePath)).thenReturn(expectedResult);
        }

        final String serviceResponse = packerService.packInput(filePath);

        assertEquals(serviceResponse, expectedResult);
    }

    @Test
    public void whenFileDoesNotExist_thenAPIException() throws APIException {
        final String expectedMessage = Constants.FILE_READ_ERROR_MESSAGE;

        Exception exception = assertThrows(APIException.class, () -> {
            final String filePath = "src/main/test/resources/non_existing_file";

            final String serviceResponse = packerService.packInput(filePath);
        });

        assertEquals(exception.getMessage(), expectedMessage);
    }

    @Test
    public void whenInputExceedsWeight_thenAPIException() throws APIException {
        final String expectedMessage = Constants.MAX_WEIGHT_ERROR_MESSAGE;

        Exception exception = assertThrows(APIException.class, () -> {
            final String filePath = "src/main/test/resources/weight_exceed";

            final String serviceResponse = packerService.packInput(filePath);
        });

        assertEquals(exception.getMessage(), expectedMessage);
    }

    @Test
    public void whenInputExceedsCost_thenAPIException() throws APIException {
        final String expectedMessage = Constants.MAX_COST_ERROR_MESSAGE;

        Exception exception = assertThrows(APIException.class, () -> {
            final String filePath = "src/main/test/resources/cost_exceed";

            final String serviceResponse = packerService.packInput(filePath);
        });

        assertEquals(exception.getMessage(), expectedMessage);
    }

    @Test
    public void whenInputExceedsItems_thenAPIException() throws APIException {
        final String expectedMessage = Constants.MAX_ITEMS_ERROR_MESSAGE;

        Exception exception = assertThrows(APIException.class, () -> {
            final String filePath = "src/main/test/resources/item_exceeded";

            final String serviceResponse = packerService.packInput(filePath);
        });

        assertEquals(exception.getMessage(), expectedMessage);
    }
}
