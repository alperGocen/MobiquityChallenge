package com.mobiquity.service;

import com.mobiquity.exception.APIException;

import java.util.List;

public interface PackerService {
    String packInput(String filePath) throws APIException;
}
