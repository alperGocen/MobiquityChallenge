package com.mobiquity.service.impl;

import com.mobiquity.exception.APIException;
import com.mobiquity.service.PackerService;
import org.springframework.stereotype.Service;
import com.mobiquity.packer.Packer;

@Service
public class PackerServiceImpl implements PackerService {

    public String packInput(final String filePath) throws APIException {
        return Packer.pack(filePath);
    }
}
