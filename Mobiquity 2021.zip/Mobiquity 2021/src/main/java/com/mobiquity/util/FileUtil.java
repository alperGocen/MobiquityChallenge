package com.mobiquity.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class FileUtil {

    // *** Using List<String> and BufferedReader here since it is the most efficient approach for reading files ****
    public static List<String> bufferReaderToList(String path, List<String> list) throws IOException {
        try {
            final BufferedReader in = new BufferedReader(
                    new InputStreamReader(new FileInputStream(path), StandardCharsets.UTF_8));

            String line;
            while ((line = in.readLine()) != null) {
                list.add(line);
            }

            in.close();
        } catch (final IOException e) {
            throw new IOException();
        }
        return list;
    }
}
