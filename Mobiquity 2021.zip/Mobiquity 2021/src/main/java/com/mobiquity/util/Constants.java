package com.mobiquity.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {

    // Messages
    public String FILE_READ_ERROR_MESSAGE = "An error occurred reading provided file";
    public String INPUT_FILE_ERROR_MESSAGE = "The file has invalid input";
    public String MAX_COST_ERROR_MESSAGE = "An item's cost exceeded the maximum";
    public String MAX_WEIGHT_ERROR_MESSAGE = "An item's weight exceeded the maximum";
    public String MAX_ITEMS_ERROR_MESSAGE = "Number of items exceeded the maximum";

    // App Constants
    public String WEIGHT_ITEM_DELIMITER = " : ";
    public String EMPTY_STRING = "";
    public String BLANK_SPACE = " ";
    public String LEFT_PARANTHESIS = "(";
    public String RIGHT_PARANTHESIS = ")";
    public String COMMA = ",";
    public String DELIMITER = ", ";
    public String NEW_LINE = "\n";
    public String EURO_SIGN = "€";

    // Limitations
    public int MAX_WEIGHT = 100;
    public int MAX_ITEMS = 15;
    public int MAX_COST = 100;
}
