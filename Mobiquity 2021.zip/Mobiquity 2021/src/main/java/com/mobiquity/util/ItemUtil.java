package com.mobiquity.util;

import com.mobiquity.exception.APIException;
import com.mobiquity.model.Item;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ItemUtil {

    public static List<Item> extractItemFromString(final List<String> itemList) throws NumberFormatException{
        final List<Item> items = new ArrayList<>();

        for (String item : itemList) {
            item = item.replace(Constants.LEFT_PARANTHESIS, Constants.EMPTY_STRING);
            item = item.replace(Constants.RIGHT_PARANTHESIS, Constants.EMPTY_STRING);

            final String [] itemSpecs = item.split(Constants.COMMA);

            try {
                items.add(new Item(
                        Short.parseShort(itemSpecs[0]),
                        Double.parseDouble(itemSpecs[1]),
                        Double.parseDouble(itemSpecs[2].replace(Constants.EURO_SIGN, Constants.EMPTY_STRING))));
            } catch (final NumberFormatException exception) {
                throw new NumberFormatException();
            }
        }

        return items;
    }

    public static List<String> calculateBestFit(final double maximumWeight, final List<Item> itemList)
            throws APIException {

        if (itemList.size() > 15) {
            throw new APIException(Constants.MAX_ITEMS_ERROR_MESSAGE);
        }

        List<Item> bestFitList = new ArrayList<>();
        // 1. Sort descending by cost
        Collections.sort(itemList, Collections.reverseOrder());
        double totalCostSum = 0.0;

        // 2. start putting items in list until it exceeds the weight limit
        // After every item removal the list size decreases by one when the list size is 0 stop
        // This operation takes O(N^2) time however the input size is at most 15
        while (itemList.size() > 0) {
            double totalWeightSum = 0.0;
            int itemCounter = 0;
            double candidateCostSum = 0.0;
            final List<Item> candidateItemList = new ArrayList<>();

            // until totalweight is smaller than maximum weight continue this operation
            while(itemCounter < itemList.size() && totalWeightSum <= maximumWeight) {
                final Item currentItem = itemList.get(itemCounter);

                if (currentItem.getCost() > Constants.MAX_COST) {
                    throw new APIException(Constants.MAX_COST_ERROR_MESSAGE);
                }

                if (currentItem.getWeight() > Constants.MAX_WEIGHT) {
                    throw new APIException(Constants.MAX_WEIGHT_ERROR_MESSAGE);
                }

                // Check before entering adding this element on top will exceed the totalWeight
                if (totalWeightSum + currentItem.getWeight() <= maximumWeight) {
                    candidateItemList.add(currentItem);

                    totalWeightSum += currentItem.getWeight();
                    candidateCostSum += currentItem.getCost();
                }
                itemCounter++;
            }
            // if new total is greater than old total the candidate list is a better option than old bestFitList
            if (candidateCostSum > totalCostSum) {
                totalCostSum = candidateCostSum;
                bestFitList = candidateItemList;
            }

            itemList.remove(itemList.get(itemList.size() - 1));
        }

        // 3. return the indexes of items as a list
        return bestFitList.stream().map(item -> String.valueOf(item.getIndex_number())).collect(Collectors.toList());
    }
}
