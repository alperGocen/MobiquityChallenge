package com.mobiquity.packer;

import com.mobiquity.exception.APIException;
import com.mobiquity.model.Item;
import com.mobiquity.util.Constants;
import com.mobiquity.util.FileUtil;
import com.mobiquity.util.ItemUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Packer {

    public Packer() {
    }

    // Param : filePath
    // Operation : Returns the best fitting result
    public static String pack(final String filePath) throws APIException {
        try {
            final List<List<String>> resultList = new ArrayList<>();
            final List<String> lineInputs = FileUtil.bufferReaderToList(filePath, new ArrayList<>());

            for (final String line : lineInputs) {
                final String [] lineSplit = line.split(Constants.WEIGHT_ITEM_DELIMITER);
                
                final double maximumWeight = Double.parseDouble(lineSplit[0]);
                final List<String> itemsList = Arrays.asList(lineSplit[1].split(Constants.BLANK_SPACE));
                
                final List<Item> resultItemList = ItemUtil.extractItemFromString(itemsList);
                final List<String> resultIntegerList = ItemUtil.calculateBestFit(maximumWeight, resultItemList);

                resultList.add(resultIntegerList);
            }

            return extractFinalOutput(resultList);
        } catch (final IOException IOException) {
            throw new APIException(Constants.FILE_READ_ERROR_MESSAGE);
        } catch (final NumberFormatException numberFormatException) {
            throw new APIException(Constants.INPUT_FILE_ERROR_MESSAGE);
        }
    }

    private static String extractFinalOutput(final List<List<String>> resultList) {
        final StringBuilder stringBuilder = new StringBuilder();

        for (List<String> innerList : resultList) {
            if (innerList.isEmpty()) {
                stringBuilder.append("-\n");
            } else {
                final String singlePackage = String.join(Constants.DELIMITER, innerList);
                stringBuilder.append(singlePackage + Constants.NEW_LINE);
            }
        }

        return stringBuilder.toString();
    }
}
