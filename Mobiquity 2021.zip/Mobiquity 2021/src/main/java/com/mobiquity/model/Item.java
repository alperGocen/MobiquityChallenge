package com.mobiquity.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Item implements Comparable<Item>{

    private int index_number;
    private double weight;
    private Double cost;

    @Override
    public int compareTo(final Item item) {
       return this.getCost().compareTo(item.getCost());
    }

    public Item maxCostItem(final Item item) {
        if (this.getCost() >= item.getCost()) {
            return this;
        } else {
            return item;
        }
    }
}
